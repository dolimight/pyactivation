from pyactivation.licensekey import v1
from pyactivation.licensekey import v2